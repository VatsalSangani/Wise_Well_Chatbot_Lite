import faiss
import torch
import pandas as pd
from sentence_transformers import SentenceTransformer
from transformers import GPT2Tokenizer, GPT2LMHeadModel

# Load corpus
df = pd.read_csv("corpus/medical_facts.csv")  # Must contain a 'text' column
corpus = df["text"].tolist()

# Step 1: Embed corpus
embedder = SentenceTransformer("all-MiniLM-L6-v2")
corpus_embeddings = embedder.encode(corpus, convert_to_tensor=True, show_progress_bar=True)

# Step 2: Build FAISS index
index = faiss.IndexFlatL2(corpus_embeddings.shape[1])
index.add(corpus_embeddings.cpu().numpy())

# Step 3: Load fine-tuned GPT2 model
tokenizer = GPT2Tokenizer.from_pretrained("distilgpt2-medical-lora")
tokenizer.pad_token = tokenizer.eos_token
model = GPT2LMHeadModel.from_pretrained("distilgpt2-medical-lora")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Step 4: RAG-style Answer Generator
def generate_rag_answer(query, top_k=3):
    query_embedding = embedder.encode([query], convert_to_tensor=True)
    D, I = index.search(query_embedding.cpu().numpy(), top_k)
    retrieved_context = "\n".join([corpus[i] for i in I[0]])

    prompt = f"Q: {query}\nContext: {retrieved_context}\nA:"
    inputs = tokenizer(prompt, return_tensors="pt", padding=True, truncation=True, max_length=512)
    input_ids = inputs["input_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    output = model.generate(
        input_ids=input_ids,
        attention_mask=attention_mask,
        max_new_tokens=100,
        pad_token_id=tokenizer.eos_token_id
    )

    response = tokenizer.decode(output[0], skip_special_tokens=True)
    return response.replace(prompt, "").strip()
