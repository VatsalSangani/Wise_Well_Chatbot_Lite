import torch
from datasets import load_dataset
from transformers import (
    GPT2Tokenizer,
    GPT2LMHeadModel,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model, TaskType

# 🔹 Load dataset
dataset = load_dataset("json", data_files="qa_combined_finetune.json", split="train")

# 🔹 Tokenizer & Model
model_name = "distilgpt2"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
tokenizer.pad_token = tokenizer.eos_token

model = GPT2LMHeadModel.from_pretrained(model_name)

def tokenize_function(batch):
    return tokenizer(
        [p + c for p, c in zip(batch["prompt"], batch["completion"])],
        padding="max_length",
        truncation=True,
        max_length=128,
    )

tokenized_dataset = dataset.map(tokenize_function, batched=True)
tokenized_dataset.set_format(type="torch", columns=["input_ids", "attention_mask"])

# 🔹 Setup LoRA config
lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["c_attn", "c_proj"],  # GPT2-specific attention/projection
    lora_dropout=0.05,
    bias="none",
    task_type=TaskType.CAUSAL_LM,
)

# 🔹 Inject LoRA into model
model = get_peft_model(model, lora_config)

# 🔹 Show device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🔥 Using device: {device}")
model.to(device)

# 🔹 Data collator for causal LM
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# 🔹 Training args
training_args = TrainingArguments(
    output_dir="./distilgpt2-medical-lora",
    per_device_train_batch_size=8,
    num_train_epochs=10,
    logging_steps=10,
    save_steps=500,
    save_total_limit=2,
    learning_rate=5e-5,
    fp16=torch.cuda.is_available(),  # use FP16 if on GPU
    report_to="none"
)

# 🔹 Trainer setup
trainer = Trainer(
    model=model,
    tokenizer=tokenizer,
    args=training_args,
    train_dataset=tokenized_dataset,
    data_collator=data_collator,
)

# 🔹 Train model
trainer.train()

# 🔹 Save trained model
trainer.save_model("./distilgpt2-medical-lora")
tokenizer.save_pretrained("./distilgpt2-medical-lora")

print("✅ Fine-tuning completed and model saved!")
