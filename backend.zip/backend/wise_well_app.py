from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import torch
import faiss
import pandas as pd
from transformers import GPT2LMHeadModel, GPT2Tokenizer
from sentence_transformers import SentenceTransformer
import os

print("🟢 Starting Wise Well FastAPI App...")

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check route
@app.get("/")
def health():
    return {"status": "Wise Well is running!"}

# Request schema
class QueryRequest(BaseModel):
    question: str

try:
    # Load corpus
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    corpus_path = os.path.join(BASE_DIR, "..", "corpus", "medical_facts.csv")

    if not os.path.exists(corpus_path):
        raise FileNotFoundError(f"📂 Corpus file not found at: {corpus_path}")

    print("📘 Loading corpus...")
    df = pd.read_csv(corpus_path)
    corpus = df["text"].tolist()

    # Load sentence-transformer
    print("💬 Loading sentence transformer model...")
    embedder = SentenceTransformer(os.path.join(BASE_DIR, "..", "sentence_model"))
    print("✅ Sentence model loaded")

    corpus_embeddings = embedder.encode(corpus, convert_to_tensor=True)
    index = faiss.IndexFlatL2(corpus_embeddings.shape[1])
    index.add(corpus_embeddings.cpu().numpy())

    # Load LLM
    print("🧠 Loading GPT-2 model...")
    model_path = os.path.join(BASE_DIR, "..", "distilgpt2-merged")
    tokenizer = GPT2Tokenizer.from_pretrained(model_path, local_files_only=True)
    tokenizer.pad_token = tokenizer.eos_token
    model = GPT2LMHeadModel.from_pretrained(model_path, local_files_only=True).to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    print("✅ GPT-2 model loaded")

except Exception as e:
    print(f"❌ Error during model setup: {e}")
    raise e

@app.post("/ask")
def ask_bot(request: QueryRequest):
    query = request.question.strip()
    if not query:
        return {"answer": "No question provided.", "context": ""}

    query_embedding = embedder.encode([query], convert_to_tensor=True)
    D, I = index.search(query_embedding.cpu().numpy(), k=3)
    retrieved_context = "\n".join([corpus[i] for i in I[0]])

    prompt = f"Q: {query}\nContext: {retrieved_context}\nA:"
    inputs = tokenizer(prompt, return_tensors="pt", padding=True, truncation=True, max_length=512)
    input_ids = inputs["input_ids"].to(model.device)
    attention_mask = inputs["attention_mask"].to(model.device)

    output = model.generate(
        input_ids=input_ids,
        attention_mask=attention_mask,
        max_new_tokens=100,
        pad_token_id=tokenizer.eos_token_id
    )

    answer = tokenizer.decode(output[0], skip_special_tokens=True)
    return {
        "answer": answer.replace(prompt, "").strip(),
        "context": retrieved_context
    }
